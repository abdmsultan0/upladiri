package com.reactsupport

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.aliucord.Utils
import com.aliucord.api.SettingsAPI
import com.aliucord.fragments.SettingsPage
import com.aliucord.widgets.BottomSheet
import com.discord.views.CheckedSetting

/** Bottom sheet with: Add IDs / Set react time / Start-Stop */
class ReactSupportSettings(private val settings: SettingsAPI) : BottomSheet() {

    override fun onViewCreated(view: View, bundle: Bundle?) {
        super.onViewCreated(view, bundle)
        val ctx = requireContext()

        // ---- 1) Add IDs -------------------------------------------------
        val idsButton = Button(ctx)
        fun refreshIdsLabel() {
            idsButton.text = "Add IDs  (${ReactSupport.getIds(settings).size} saved)"
        }
        refreshIdsLabel()
        idsButton.setOnClickListener {
            val input = EditText(ctx).apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                hint = "One user ID per line"
                setText(ReactSupport.getIds(settings).joinToString("\n"))
            }
            AlertDialog.Builder(ctx)
                .setTitle("User IDs")
                .setMessage("Add or remove IDs (one per line, or separated by commas).")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val ids = input.text.toString()
                        .split(Regex("[\\s,;]+"))
                        .mapNotNull { it.trim().toLongOrNull() }
                        .distinct()
                    settings.setString(ReactSupport.KEY_IDS, ids.joinToString("\n"))
                    refreshIdsLabel()
                    Toast.makeText(ctx, "${ids.size} ID(s) saved", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        addView(idsButton)

        // ---- 2) Set react time ------------------------------------------
        val timeButton = Button(ctx)
        fun refreshTimeLabel() {
            timeButton.text = "Set react time  (${ReactSupport.getDelaySeconds(settings)} s)"
        }
        refreshTimeLabel()
        timeButton.setOnClickListener {
            val input = EditText(ctx).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                hint = "Seconds, e.g. 2 or 0.5"
                setText(ReactSupport.getDelaySeconds(settings).toString())
            }
            AlertDialog.Builder(ctx)
                .setTitle("React time")
                .setMessage("How many seconds to wait before reacting (also the minimum gap between two reactions).")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val v = input.text.toString().toDoubleOrNull()
                    if (v == null || v < 0) {
                        Toast.makeText(ctx, "Invalid number", Toast.LENGTH_SHORT).show()
                    } else {
                        settings.setString(ReactSupport.KEY_DELAY, v.toString())
                        refreshTimeLabel()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        addView(timeButton)

        // ---- 3) Start / Stop --------------------------------------------
        val running = Utils.createCheckedSetting(
            ctx,
            CheckedSetting.ViewType.SWITCH,
            "Start / Stop",
            "ON = react to the saved IDs' reactions on your messages"
        ).apply {
            isChecked = settings.getBool(ReactSupport.KEY_RUNNING, false)
            setOnCheckedListener { checked ->
                settings.setBool(ReactSupport.KEY_RUNNING, checked)
                Toast.makeText(ctx, if (checked) "Started" else "Stopped", Toast.LENGTH_SHORT).show()
            }
        }
        addView(running)
    }
}
