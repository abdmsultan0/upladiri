package com.reactsupport

import android.content.Context
import com.aliucord.Http
import com.aliucord.Logger
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.Hook
import com.aliucord.utils.ReflectUtils
import com.discord.stores.StoreMessageReactions
import com.discord.stores.StoreStream
import java.net.URLEncoder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * ReactSupport
 *
 * When STARTED, every time one of the saved user IDs adds a reaction to one of
 * YOUR OWN messages, the plugin adds the exact same emoji to that message
 * after the delay you configured.
 */
@AliucordPlugin
class ReactSupport : Plugin() {

    private val logger = Logger("ReactSupport")

    @Volatile
    private var executor: ExecutorService? = null

    override fun start(context: Context) {
        executor = Executors.newSingleThreadExecutor()

        // Settings sheet (the "settings" button of the plugin)
        settingsTab = SettingsTab(ReactSupportSettings::class.java, SettingsTab.Type.BOTTOM_SHEET)
            .withArgs(settings)

        // Gateway event MESSAGE_REACTION_ADD ends up in this store method
        patcher.patch(
            StoreMessageReactions::class.java,
            "handleReactionAdd",
            arrayOf<Class<*>>(List::class.java),
            Hook { callFrame ->
                try {
                    if (!settings.getBool(KEY_RUNNING, false)) return@Hook
                    val updates = callFrame.args[0] as? List<*> ?: return@Hook
                    for (update in updates) {
                        if (update != null) handleUpdate(update)
                    }
                } catch (t: Throwable) {
                    logger.error("hook failed", t)
                }
            }
        )
    }

    override fun stop(context: Context) {
        executor?.shutdownNow()
        executor = null
        patcher.unpatchAll()
    }

    // ------------------------------------------------------------------

    private fun handleUpdate(update: Any) {
        val userId = ReflectUtils.getField(update, "userId") as Long
        val channelId = ReflectUtils.getField(update, "channelId") as Long
        val messageId = ReflectUtils.getField(update, "messageId") as Long
        val emoji = ReflectUtils.getField(update, "emoji") ?: return

        val myId = StoreStream.getUsers().me.id
        if (userId == myId) return                       // ignore my own reactions
        if (userId !in getIds(settings)) return          // only the IDs I added

        val emojiId = ReflectUtils.getField(emoji, "id") as? String
        val emojiName = ReflectUtils.getField(emoji, "name") as? String ?: return
        val emojiPath = if (emojiId.isNullOrEmpty()) emojiName else "$emojiName:$emojiId"

        executor?.execute {
            try {
                // 1) only react if the message is MINE
                if (!isMyMessage(channelId, messageId, myId)) return@execute

                // 2) wait the configured time (also spaces out reactions -> rate limits)
                val delayMs = (getDelaySeconds(settings) * 1000).toLong()
                if (delayMs > 0) Thread.sleep(delayMs)

                // 3) user may have pressed Stop while we were waiting
                if (!settings.getBool(KEY_RUNNING, false)) return@execute

                react(channelId, messageId, emojiPath)
            } catch (_: InterruptedException) {
                // plugin stopped
            } catch (t: Throwable) {
                logger.error("failed to react", t)
            }
        }
    }

    private fun isMyMessage(channelId: Long, messageId: Long, myId: Long): Boolean {
        // Fast path: message is in Discord's cache
        try {
            val msg = StoreStream.getMessages().getMessage(channelId, messageId)
            if (msg != null) {
                val author = ReflectUtils.getField(msg, "author")
                val authorId = author?.let { ReflectUtils.getField(it, "id") }
                if (authorId is Long) return authorId == myId
            }
        } catch (_: Throwable) { /* fall back to REST */ }

        // Slow path: ask the API (message was not loaded locally)
        return try {
            val res = Http.Request.newDiscordRNRequest(
                "/channels/$channelId/messages?around=$messageId&limit=1", "GET"
            ).execute()
            val list = res.json(Array<ApiMessage>::class.java)
            list.firstOrNull { it.id == messageId.toString() }?.author?.id == myId.toString()
        } catch (t: Throwable) {
            logger.error("could not check message author", t)
            false
        }
    }

    private fun react(channelId: Long, messageId: Long, emojiPath: String) {
        val enc = URLEncoder.encode(emojiPath, "UTF-8").replace("+", "%20")
        Http.Request.newDiscordRNRequest(
            "/channels/$channelId/messages/$messageId/reactions/$enc/@me", "PUT"
        ).execute()
    }

    // minimal models for the REST fallback
    private data class ApiAuthor(val id: String?)
    private data class ApiMessage(val id: String?, val author: ApiAuthor?)

    companion object {
        const val KEY_IDS = "ids"
        const val KEY_DELAY = "delaySeconds"
        const val KEY_RUNNING = "running"

        fun getIds(settings: com.aliucord.api.SettingsAPI): Set<Long> =
            settings.getString(KEY_IDS, "")
                .split(Regex("[\\s,;]+"))
                .mapNotNull { it.trim().toLongOrNull() }
                .toSet()

        fun getDelaySeconds(settings: com.aliucord.api.SettingsAPI): Double =
            settings.getString(KEY_DELAY, "2").toDoubleOrNull()?.coerceAtLeast(0.0) ?: 2.0
    }
}
