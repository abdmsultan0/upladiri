version = "1.0.0"
description = "Reacts with the same emoji when chosen users react to your messages"

aliucord {
    changelog.set("Initial release")
    author("ReactSupport", 0L)
}
